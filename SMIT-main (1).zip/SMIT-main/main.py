from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from routes import student_routes
load_dotenv()



app = FastAPI(
    title="Login and Agent Management API",
    description="API for managing user logins and agent information",
    version="1.0.0",
    docs_url="/docs",          
    redoc_url="/redoc"         
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(student_routes.student_router, prefix="/students", tags=["Student"])



if __name__ == "__main__":
    # for local dev only
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

