import email
from email import message
from pydantic import BaseModel,Field,AfterValidator
from typing_extensions import Annotated


    

class add_stuedent:
    name:str
    id:int
    email:str
    departement:str